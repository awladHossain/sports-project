$(document).ready(function() {
    $(".toggle-password").click(function() {

        $(this).toggleClass("toggle-password");
        var input = $($(this).attr("toggle"));
        if (input.attr("type") == "password") {
            input.attr("type", "text");
        } else {
            input.attr("type", "password");
        }
    });

    $(".toggle-confirm-password").click(function() {

        $(this).toggleClass("toggle-confirm-password");
        var input = $($(this).attr("toggle"));
        if (input.attr("type") == "password") {
            input.attr("type", "text");
        } else {
            input.attr("type", "password");
        }
    });

});